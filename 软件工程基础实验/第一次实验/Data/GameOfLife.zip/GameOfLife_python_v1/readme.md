### How to launch the application?

```
python entry.py
```